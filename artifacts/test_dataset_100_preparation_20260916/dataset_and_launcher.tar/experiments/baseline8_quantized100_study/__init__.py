"""Fresh 100-task, ten-attempt, 8K-output online comparison on NAS."""
REVISION = 'nas_qwen38q4_online100_max10_output8192_v1'
UNIT = 'plc-baseline8-qwen38q4-100-max10-20260916-v1'
PREFIX = 'plc-qwen38q4-100-max10-v1'
