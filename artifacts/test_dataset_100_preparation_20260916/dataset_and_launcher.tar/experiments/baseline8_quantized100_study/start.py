"""Start the fresh 100-task run with a separate persistent monitor."""
import argparse
from pathlib import Path
from experiments.baseline8_online117_study.common import read
from experiments.baseline8_quantized200_study import start as original
from . import UNIT


def start(root):
    study=read(root/'study.json');config=read(root/'config.json')
    assert study['task_count']==100 and study['planned']==800
    assert not study['configuration_changed_mid_stream']
    assert config['protocol_candidate_limit']==config['budgets']['max_candidates']==10
    assert config['generation_output_budget']['max_output_tokens']==8192
    assert not read(root/'watchdog/config.json')['task_duration_termination_enabled']
    original.UNIT=UNIT
    original.start(root)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    start(p.parse_args().root.resolve())
