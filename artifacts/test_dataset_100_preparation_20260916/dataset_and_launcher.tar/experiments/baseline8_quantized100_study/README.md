# NAS 八基线：最长 100 题的新实验

数据为 `../../test_dataset_100_tasks`，从原 200 题中按参考代码总行数选择最长 100 题。八个方法采用同一任务顺序：任务 ID 排序后，以种子 20260914 洗牌。每个方法按顺序完成自己的 100 题，共 800 个方法—任务组合。

模型为 NAS `http://127.0.0.1:18185/v1` 上的 `qwen3.8-27b-q4_k_m`，temperature=0、seed=20260914、thinking=false。每题最多 10 次 PLC 生成，每次输出最多 8192 token；生成、检索及题后学习合计最多 64 次模型调用、200 万预算 token、200 次工具调用及 24 小时。原账本外层 max_output_tokens=65536 保留，实际生成的角色预算为 8192；请求失败时按实际预约上限计入保守预算。

Vanilla、FewShot、FinalCodeRAG、RawTrajectoryRAG 不使用本题错误反馈或上一份候选代码生成下一份候选。Memento、EverMemOS、MemSkill、MSCE 使用本题反馈。除 Vanilla 外，各方法仅在本题结束后发布自身观察所得的知识，供该方法后续任务使用。各方法从空知识库开始；旧 200 题运行的结果、轨迹、答案和已学习资产均不导入。冻结编码器及原方法已有机制保持不变。

运行根目录：NAS `/home/qyb/RESEARCH/RSI_PLC_Generation/baseline8_qwen38q4_100_max10_20260916_v1`。

监测 timer：`plc-baseline8-qwen38q4-100-max10-20260916-v1.timer`；单路恢复单元前缀为 `plc-qwen38q4-100-max10-v1`。正常交互不按单题累计 30 分钟停止；保留单请求 600 秒、无内容 180 秒、持续低速/流停滞及题后学习保护。Bark 告警和单路恢复沿用现有机制。

成功要求同一候选通过 MatIEC 编译及全部给定运行断言，扫描周期 100 ms；不执行形式验证或厂商硬件验证。交互次数、准确/未知 token 和保守预算分别保留，用于成本比较。

`prepare.py` 从已停止且通过锁校验的旧运行复制执行源码、评价器和模型配置，在独立目录准备新的数据、空知识库及协议锁。必要改动仅为任务数量、来源标签、完成通知及新运行从首轮即采用 8K 的审计规则。未改动重复候选、检索、采样和评价器未知结果策略。

该安装器修改新运行中的冻结源码，不改写旧运行。`tests.py` 在部署后的新源码路径中执行；同时运行既有反馈、十次上限、容量并发、截断、成本和监测检查。`baseline8_online200_study.preflight` 的模块名作为复用实现保留，其任务数来自新数据包和 study.json。

在 NAS 使用既有 Python 环境及新运行 `watchdog/config.json` 的 environment：

```sh
python -B -m experiments.baseline8_online200_study.preflight --root <新运行目录>
python -B -m experiments.baseline8_quantized100_study.start --root <新运行目录>
```

启动器要求回归检查、800 个空库边界检查、真实编译/运行正负例和独立模型探针全部通过。它只允许启动空的新运行；不自动重置任何已有任务账本。原 200 题实验保持 STOP、监测禁用，185 项已结束结果独立保存。
