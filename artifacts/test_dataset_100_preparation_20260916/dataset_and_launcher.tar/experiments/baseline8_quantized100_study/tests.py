"""Count, fresh-output-audit and monitor-completion regression cases."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from experiments.baseline8_online117_study.common import read, save
from experiments.baseline8_online117_study.memory import empty_snapshot
from experiments.baseline8_online200_study import METHODS
from experiments.baseline8_online200_study.audit import audit
from experiments.baseline8_online200_study.run import report
from experiments.baseline8_mixedfeedback200_study import FEEDBACK
from experiments.baseline8_output8k_v5.policy import expected_output_limit
from baseline8_online200_watchdog import monitor


class FreshHundredTests(unittest.TestCase):
    def setup_root(self, root):
        save(root/'protocol.lock.json',{})
        save(root/'study.json',{'task_count':100,'task_ids':['T%03d'%i for i in range(100)],
            'planned':800,'source_split':'test_dataset_100_tasks','interpretation':'fixture'})
        save(root/'config.json',{'generation_output_budget':{'max_output_tokens':8192},
                                'current_task_feedback_by_method':FEEDBACK})
        for method in METHODS:empty_snapshot(root/'streams'/method/'snapshots/0000',method)

    def test_fresh_8k_audit_needs_no_legacy_amendment(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.setup_root(root)
            self.assertEqual(expected_output_limit(root,root/'tests/Vanilla/T000',1),8192)
            self.assertFalse((root/'output_budget_amendment.json').exists())

    def test_empty_100_task_report_and_partial_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.setup_root(root)
            value=report(root)
            self.assertEqual(value['planned'],800)
            self.assertTrue(all(x['planned']==100 for x in value['methods']))
            self.assertEqual(audit(root,partial=True)['tasks'],0)
            with self.assertRaisesRegex(ValueError,'configured method-task summaries'):
                audit(root)

    def test_monitor_completion_uses_800_and_not_previous_1600(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.setup_root(root)
            save(root/'watchdog/config.json',{})
            save(root/'completion_audit.json',{'status':'pass'})
            processes={'workers':{},'tasks':{},'scheduler':[]}
            with patch.object(monitor,'deliver'), patch.object(monitor,'process_table',return_value={}), \
                 patch.object(monitor,'classified',return_value=processes), \
                 patch.object(monitor,'observe',return_value={'complete':True,'completed':100,'order':100,'task_id':'T099'}), \
                 patch.object(monitor,'decisions',return_value=(None,None)), \
                 patch.object(monitor,'report',return_value={'complete':True,'completed':800}), \
                 patch.object(monitor,'notify') as notification:
                monitor.tick(root)
            self.assertEqual(read(root/'state.json')['completed'],800)
            self.assertIn('800',notification.call_args.args[2])
            self.assertNotIn('1600',notification.call_args.args[2])


if __name__=='__main__':unittest.main()
