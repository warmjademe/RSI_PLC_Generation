"""Prepare a separate empty run from the stopped and verified 200-task runtime."""
import argparse
from pathlib import Path
import random
import shutil
import time

from experiments.baseline8_online117_study.common import read, save, sha, inventory, validate
from experiments.baseline8_online117_study.memory import empty_snapshot, check_snapshot
from experiments.baseline8_mixedfeedback200_study.prepare import replace_once, remap
from . import REVISION, PREFIX


def patch_sources(root):
    base = root/'source'
    p = base/'experiments/baseline8_online200_study/setup.py'
    replace_once(p, '    assert selection["task_count"] == manifest["task_count"] == 200',
        '    count = selection["task_count"]\n    assert count in (100, 200) and count == manifest["task_count"]')
    replace_once(p, '    assert len(ids) == len(set(ids)) == 200', '    assert len(ids) == len(set(ids)) == count')
    replace_once(p, 'counts = {"tasks": 200,', 'counts = {"tasks": count,')
    p = base/'experiments/baseline8_online200_study/preflight.py'
    replace_once(p, 'and len(ids) == 200', 'and len(ids) == study["task_count"]')
    replace_once(p, '"methods": 8, "tasks": 200,', '"methods": len(METHODS), "tasks": study["task_count"],')
    p = base/'experiments/baseline8_online200_study/tests.py'
    replace_once(p, '        self.assertEqual(len(ids), 200)\n        self.assertEqual(stats, {"tasks": 200, "cases": 1026, "steps": 3804, "scans": 5615, "assertions": 32590})',
        '        expected = {200: {"tasks": 200, "cases": 1026, "steps": 3804, "scans": 5615, "assertions": 32590},\n'
        '                    100: {"tasks": 100, "cases": 516, "steps": 1886, "scans": 2845, "assertions": 16644}}[read(dataset / "selection.json")["task_count"]]\n'
        '        self.assertEqual(len(ids), expected["tasks"])\n        self.assertEqual(stats, expected)')
    p = base/'experiments/baseline8_online200_study/audit.py'
    replace_once(p, 'assert study["task_count"] == 200 and study["planned"] == 1600',
        'assert study["task_count"] == len(study["task_ids"]) and study["planned"] == len(METHODS)*study["task_count"]')
    replace_once(p, 'completion audit requires all 1600 summaries', 'completion audit requires all configured method-task summaries')
    replace_once(p, '== "test_dataset_200_tasks"', '== study["source_split"]')
    p = base/'experiments/baseline8_output8k_v5/policy.py'
    replace_once(p, '    if not path.exists():\n        return 65536',
        '    if not path.exists():\n        config_path = root / "config.json"\n'
        '        config = read(config_path) if config_path.exists() else {}\n'
        '        return config.get("generation_output_budget", {}).get("max_output_tokens", 65536)')
    p = base/'experiments/baseline8_online200_study/run.py'
    replace_once(p, '"source_split": "test_dataset_200_tasks",', '"source_split": study["source_split"],')
    replace_once(p, '"planned": 1600}', '"planned": read(root / "study.json")["planned"]}')
    replace_once(p, '"planned": 1600, "lanes": exits}', '"planned": read(root / "study.json")["planned"], "lanes": exits}')
    replace_once(p, '"completed": 1600, "epoch": time.time()}', '"completed": value["completed"], "epoch": time.time()}')
    replace_once(p, 'notify(root, "NAS 八基线 200 题实验完成", "1600 项编译与运行测试结果已完成并通过审计。", "completion")',
        'notify(root, "NAS 八基线实验完成", str(value["completed"]) + " 项编译与运行测试结果已完成并通过审计。", "completion")')
    for folder in [base/'experiments/baseline8_online200_watchdog',root/'ops/watchdog_v3/baseline8_online200_watchdog']:
        for name in ['recovery.py','slow_finalize.py']:
            p=folder/name
            replace_once(p, '"source_split": "test_dataset_200_tasks",', '"source_split": read(root / "study.json")["source_split"],')
        p=folder/'monitor.py'
        replace_once(p, '"completed": 1600, "epoch": time.time()}', '"completed": value["completed"], "epoch": time.time()}')
        replace_once(p, 'notify(root, "NAS 八基线 200 题实验完成", "1600 项编译与运行测试结果已完成并通过审计。", "completion")',
            'notify(root, "NAS 八基线实验完成", str(value["completed"]) + " 项编译与运行测试结果已完成并通过审计。", "completion")')
        replace_once(p, "{obs['completed']}/200 题", "{obs['completed']}/{study['task_count']} 题")
        replace_once(p, "{obs['order']}/200 题", "{obs['order']}/{study['task_count']} 题")
    p=base/'experiments/baseline8_quantized200_study/start.py'
    replace_once(p, '"planned": 1600}', '"planned": study["planned"]}')
    # The validator already uses the exact IDs from study.json; only diagnostics were fixed at 200.
    for p in [root/'validator200.py',base/'experiments/baseline8_online200_study/validator.py']:
        replace_once(p, 'task outside the fixed 200-task protocol', 'task outside the fixed study task IDs')
        replace_once(p, '200-task scan period must be 100 ms', 'study scan period must be 100 ms')


def prepare(old, root, dataset):
    validate(old)
    assert (old/'STOP').exists() and (old/'watchdog/PAUSE').exists()
    selection=read(dataset/'selection.json');manifest=read(dataset/'manifest.json')
    assert selection['task_count']==manifest['task_count']==len(selection['tasks'])==100
    assert not selection['reference_programs_in_package']
    for name,digest in manifest['files'].items():assert sha(dataset/name)==digest
    parent_ids=set(read(old/'study.json')['task_ids'])
    ids=[x['task_id'] for x in selection['tasks']]
    assert len(set(ids))==100 and set(ids)<=parent_ids
    for t in selection['tasks']:
        for k in ['task_file','tests_file','evaluator_file']:
            assert sha(dataset/t[k])==sha(old/'dataset'/t[k])
    root.mkdir(parents=True,exist_ok=False)
    save(root/'STOP',{'reason':'fresh 100-task run preparing; preflight required'})
    ignore=shutil.ignore_patterns('__pycache__','*.pyc','._*')
    for name in ['source','evaluator_source','ops/watchdog_v3/baseline8_online200_watchdog','ops/monitor_v4/baseline8_quantized200_monitor_v4']:
        shutil.copytree(old/name,root/name,ignore=ignore)
    shutil.copytree(dataset,root/'dataset',ignore=ignore)
    package=Path(__file__).resolve().parent
    shutil.copytree(package,root/'source/experiments'/package.name,ignore=ignore)
    for name in ['validator200.py','control_inputs.json','model_deployment_manifest.json','model_service_amendment.json']:
        shutil.copy2(old/name,root/name)
    save(root/'tool_config.json',remap(read(old/'tool_config.json'),old,root))
    patch_sources(root)
    cfg=remap(read(old/'config.json'),old,root)
    cfg['generation_output_budget'].update(revision=REVISION,scope='all PLC generations from the first call of this fresh 100-task run')
    assert cfg['budgets']['max_candidates']==cfg['protocol_candidate_limit']==10
    assert cfg['generation_output_budget']['max_output_tokens']==8192
    save(root/'config.json',cfg)
    ids.sort();random.Random(20260914).shuffle(ids)
    (root/'public').mkdir()
    for tid in ids:shutil.copy2(root/'dataset/tasks'/(tid+'.json'),root/'public'/(tid+'.json'))
    prep=read(dataset/'preparation_report.json')
    counts={'tasks':100,'cases':prep['source_test_cases'],'steps':prep['normalized_test_steps'],
            'scans':prep['scheduled_scans'],'assertions':prep['scheduled_assertions']}
    study=read(old/'study.json')
    study.update(created_epoch=time.time(),task_ids=ids,task_count=100,planned=800,
        dataset_id=selection['dataset_id'],source_split='test_dataset_100_tasks',counts=counts,
        source_revision=REVISION,old_study_root=str(old),old_protocol_lock_sha256=sha(old/'protocol.lock.json'),
        configuration_changed_mid_stream=False,initial_model_assets_from_previous_run=False,
        memory_initialization='all eight streams start empty; no previous experiment observations or learned assets imported',
        interpretation='Online learning on the 100 longest references within the existing 200-task pool; previous exposure retained in provenance; no historical trajectories or answers loaded; not an independent unseen holdout. Uniform 8192 generation output limit from start.')
    save(root/'study.json',study)
    for method in study['methods']:
        path=root/'streams'/method/'snapshots/0000';empty_snapshot(path,method)
        state=check_snapshot(path,method,0);assert not state['episodes'] and state['learned']==0
    watch=remap(read(old/'watchdog/config.json'),old,root)
    watch['recovery_unit_prefix']=PREFIX
    # Rebuild the search path rather than inheriting duplicate or historical entries.
    watch['environment']['PYTHONPATH']=':'.join(str(root/n) for n in ['ops/monitor_v4','ops/watchdog_v3','source'])
    save(root/'watchdog/config.json',watch)
    timing=read(old/'watchdog/timing_policy_v4.json');timing.update(scope='enabled before first task of fresh 100-task run')
    save(root/'watchdog/timing_policy_v4.json',timing)
    oldsource=inventory(old/'source');newsource=inventory(root/'source')
    provenance={'parent_root':str(old),'parent_protocol_sha256':sha(old/'protocol.lock.json'),
        'parent_stop':read(old/'STOP'),'authorization':'User requested top 100 tasks and restart all eight baselines',
        'imported_task_results':0,'imported_history_records':0,'dataset_manifest_sha256':sha(dataset/'manifest.json'),
        'preserved_old_completed':len(list((old/'tests').glob('*/*/summary.json'))),
        'source_changes':{p:{'old_sha256':oldsource.get(p),'new_sha256':h} for p,h in newsource.items() if oldsource.get(p)!=h}}
    save(root/'source_origin.json',provenance)
    lock={}
    for name in ['source','dataset','public','evaluator_source','ops/watchdog_v3','ops/monitor_v4']:
        lock.update({name+'/'+p:h for p,h in inventory(root/name).items()})
    for name in ['study.json','config.json','tool_config.json','validator200.py','control_inputs.json','source_origin.json',
                 'model_deployment_manifest.json','model_service_amendment.json','watchdog/config.json','watchdog/timing_policy_v4.json']:
        lock[name]=sha(root/name)
    save(root/'protocol.lock.json',lock)
    for name in ['logs','notifications','progress','bootstrap']:(root/name).mkdir(exist_ok=True)
    save(root/'state.json',{'phase':'awaiting_100_task_preflight','epoch':time.time(),'planned':800})
    validate(root);validate(old)
    return {'root':str(root),'tasks':100,'planned':800,'initial_history_records':0,'candidate_limit':10,'generation_output_tokens':8192}


if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ['old','root','dataset']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();print(prepare(a.old.resolve(),a.root.resolve(),a.dataset.resolve()))
